package com.mineair.monitoring.ui.minescene

import android.graphics.Color
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import com.mineair.monitoring.data.MineTopology
import com.mineair.monitoring.importerp.SchemaXmlParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Экран схемы шахты: при открытии парсит schema.xml (см. SchemaXmlParser) в фоне
 * и передаёт результат в MineGLRenderer. Пока парсинг идёт — показывает статус-текст.
 */
class MineSceneActivity : ComponentActivity() {

    companion object {
        const val EXTRA_MODEL_NAME = "extra_model_name"
        const val EXTRA_SCHEMA_PATH = "extra_schema_path"
    }

    private var glSurfaceView: GLSurfaceView? = null
    private lateinit var root: FrameLayout
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val modelName = intent.getStringExtra(EXTRA_MODEL_NAME) ?: "Модель"
        val schemaPath = intent.getStringExtra(EXTRA_SCHEMA_PATH) ?: ""
        title = modelName

        root = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#0F0F1A")) }
        statusText = TextView(this).apply {
            text = "Загрузка схемы…"
            setTextColor(Color.parseColor("#B3B3CC"))
            gravity = Gravity.CENTER
        }
        root.addView(
            statusText,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
        )
        setContentView(root)

        loadAndRender(schemaPath)
    }

    private fun loadAndRender(schemaPath: String) {
        if (schemaPath.isEmpty()) {
            statusText.text = "Путь к схеме не найден"
            return
        }

        lifecycleScope.launch {
            val topology: MineTopology? = try {
                withContext(Dispatchers.IO) {
                    File(schemaPath).inputStream().use { SchemaXmlParser.parse(it) }
                }
            } catch (e: Exception) {
                Log.e("MineSceneActivity", "Ошибка парсинга schema.xml", e)
                null
            }

            if (topology == null || topology.edges.isEmpty()) {
                statusText.text = "Не удалось разобрать схему выработок"
                return@launch
            }

            root.removeView(statusText)

            val newGlSurfaceView = GLSurfaceView(this@MineSceneActivity).apply {
                setEGLContextClientVersion(2)
                setRenderer(MineGLRenderer(topology))
                renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
            }
            glSurfaceView = newGlSurfaceView
            root.addView(newGlSurfaceView)
        }
    }

    override fun onPause() {
        super.onPause()
        glSurfaceView?.onPause()
    }

    override fun onResume() {
        super.onResume()
        glSurfaceView?.onResume()
    }
}
