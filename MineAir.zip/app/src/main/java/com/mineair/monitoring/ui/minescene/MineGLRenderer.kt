package com.mineair.monitoring.ui.minescene

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import com.mineair.monitoring.data.MineTopology
import com.mineair.monitoring.data.Point3D
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.max
import kotlin.math.min

/**
 * Рендерит распарсенную топологию шахты: каждая выработка (rib) — ломаная линия
 * (GL_LINES) через её точки, цвет берётся из цвета слоя (layer.colorHex).
 *
 * Геометрия нормализуется под текущий охват камеры: реальные координаты (метры,
 * могут быть тысячи единиц) переводятся в компактный диапазон вокруг начала
 * координат. Ось Y в 3D = глубина/отметка (data.z), оси X/Z = плановые координаты
 * (data.x/data.y) — как в горно-геологической съёмке (XY — план, Z — вертикаль).
 *
 * TODO на будущее: заменить линии на цилиндры радиусом из crossSectionArea (S),
 * добавить прозрачность по срезу Z и жестовое управление камерой (см. пункт 3
 * требований — сейчас камера просто медленно крутится вокруг Y).
 */
class MineGLRenderer(topology: MineTopology) : GLSurfaceView.Renderer {

    private data class LineGroup(
        val vertexBuffer: FloatBuffer,
        val indexBuffer: ShortBuffer,
        val indexCount: Int,
        val color: FloatArray
    )

    private var programHandle = 0
    private val lineGroups: List<LineGroup> = buildLineGroups(topology)

    private val mvpMatrix = FloatArray(16)
    private val projectionMatrix = FloatArray(16)
    private val viewMatrix = FloatArray(16)
    private val modelMatrix = FloatArray(16)
    private var rotationAngle = 0f

    companion object {
        private const val VERTEX_SHADER = """
            uniform mat4 uMvpMatrix;
            attribute vec4 aPosition;
            void main() {
                gl_Position = uMvpMatrix * aPosition;
            }
        """
        private const val FRAGMENT_SHADER = """
            precision mediump float;
            uniform vec4 uColor;
            void main() {
                gl_FragColor = uColor;
            }
        """
        private const val TARGET_SIZE = 6f // во сколько условных единиц вписываем всю схему
    }

    private fun buildLineGroups(topology: MineTopology): List<LineGroup> {
        if (topology.edges.isEmpty()) return emptyList()

        var minX = Float.MAX_VALUE; var maxX = -Float.MAX_VALUE
        var minY = Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
        var minZ = Float.MAX_VALUE; var maxZ = -Float.MAX_VALUE
        for (edge in topology.edges) {
            for (p in edge.points) {
                minX = min(minX, p.x); maxX = max(maxX, p.x)
                minY = min(minY, p.y); maxY = max(maxY, p.y)
                minZ = min(minZ, p.z); maxZ = max(maxZ, p.z)
            }
        }
        val centerX = (minX + maxX) / 2f
        val centerY = (minY + maxY) / 2f
        val centerZ = (minZ + maxZ) / 2f
        val extent = maxOf(maxX - minX, maxY - minY, maxZ - minZ, 1f)
        val scale = TARGET_SIZE / extent

        fun toRender(p: Point3D): Triple<Float, Float, Float> {
            val rx = (p.x - centerX) * scale
            val ry = (p.z - centerZ) * scale // глубина/отметка → вертикаль в 3D
            val rz = (p.y - centerY) * scale
            return Triple(rx, ry, rz)
        }

        val layerColors = topology.layers.associate { it.id to parseColor(it.colorHex) }
        val defaultColor = floatArrayOf(0.6f, 0.6f, 0.7f, 1f)

        return topology.edges
            .groupBy { it.layerId }
            .map { (layerId, edgesInLayer) ->
                val vertices = mutableListOf<Float>()
                val indices = mutableListOf<Short>()
                var cursor = 0

                for (edge in edgesInLayer) {
                    val start = cursor
                    for (p in edge.points) {
                        val (rx, ry, rz) = toRender(p)
                        vertices.add(rx); vertices.add(ry); vertices.add(rz)
                    }
                    for (i in 0 until edge.points.size - 1) {
                        indices.add((start + i).toShort())
                        indices.add((start + i + 1).toShort())
                    }
                    cursor += edge.points.size
                }

                val vertexBuffer = ByteBuffer.allocateDirect(vertices.size * 4)
                    .order(ByteOrder.nativeOrder()).asFloatBuffer()
                    .apply { put(vertices.toFloatArray()); position(0) }

                val indexBuffer = ByteBuffer.allocateDirect(indices.size * 2)
                    .order(ByteOrder.nativeOrder()).asShortBuffer()
                    .apply { put(indices.toShortArray()); position(0) }

                LineGroup(
                    vertexBuffer = vertexBuffer,
                    indexBuffer = indexBuffer,
                    indexCount = indices.size,
                    color = layerColors[layerId] ?: defaultColor
                )
            }
    }

    /** Цвет слоя хранится как "#AARRGGBB". */
    private fun parseColor(hex: String): FloatArray {
        return try {
            val clean = hex.removePrefix("#")
            val a = clean.substring(0, 2).toInt(16) / 255f
            val r = clean.substring(2, 4).toInt(16) / 255f
            val g = clean.substring(4, 6).toInt(16) / 255f
            val b = clean.substring(6, 8).toInt(16) / 255f
            floatArrayOf(r, g, b, a)
        } catch (_: Exception) {
            floatArrayOf(0.6f, 0.6f, 0.7f, 1f)
        }
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.06f, 0.06f, 0.1f, 1f)
        val vertexShader = compileShader(GLES20.GL_VERTEX_SHADER, VERTEX_SHADER)
        val fragmentShader = compileShader(GLES20.GL_FRAGMENT_SHADER, FRAGMENT_SHADER)
        programHandle = GLES20.glCreateProgram().also {
            GLES20.glAttachShader(it, vertexShader)
            GLES20.glAttachShader(it, fragmentShader)
            GLES20.glLinkProgram(it)
        }
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        val aspect = width.toFloat() / height.toFloat()
        Matrix.perspectiveM(projectionMatrix, 0, 45f, aspect, 0.1f, 200f)
        Matrix.setLookAtM(viewMatrix, 0, 0f, 4f, 14f, 0f, 0f, 0f, 0f, 1f, 0f)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

        rotationAngle = (rotationAngle + 0.3f) % 360f
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.rotateM(modelMatrix, 0, rotationAngle, 0f, 1f, 0f)

        val viewModel = FloatArray(16)
        Matrix.multiplyMM(viewModel, 0, viewMatrix, 0, modelMatrix, 0)
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, viewModel, 0)

        GLES20.glUseProgram(programHandle)
        val positionHandle = GLES20.glGetAttribLocation(programHandle, "aPosition")
        val colorHandle = GLES20.glGetUniformLocation(programHandle, "uColor")
        val mvpHandle = GLES20.glGetUniformLocation(programHandle, "uMvpMatrix")

        GLES20.glUniformMatrix4fv(mvpHandle, 1, false, mvpMatrix, 0)
        GLES20.glEnableVertexAttribArray(positionHandle)

        for (group in lineGroups) {
            GLES20.glVertexAttribPointer(positionHandle, 3, GLES20.GL_FLOAT, false, 0, group.vertexBuffer)
            GLES20.glUniform4fv(colorHandle, 1, group.color, 0)
            GLES20.glDrawElements(GLES20.GL_LINES, group.indexCount, GLES20.GL_UNSIGNED_SHORT, group.indexBuffer)
        }

        GLES20.glDisableVertexAttribArray(positionHandle)
    }

    private fun compileShader(type: Int, source: String): Int {
        return GLES20.glCreateShader(type).also { shader ->
            GLES20.glShaderSource(shader, source)
            GLES20.glCompileShader(shader)
        }
    }
}
